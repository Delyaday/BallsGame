/*const test = document.getElementById("test");

document.onmousemove = function(e)
{
   let x = e.offsetX;
   let y = e.offsetY;

   test.style.left = x + 20 + "px";
   test.style.top = y + 20 + "px";
}


document.onmousemove = function(e) 
{
    let x = e.offsetX;
    let y = e.offsetY;

    $("#test").css({'left': x + 50 + "px", 'top': y + 50 + "px"});
}
*/


let x, y;
document.onmousemove = function (e) {
    x = e.offsetX;
    y = e.offsetY;

    $("#hero").css({ 'left': x + 20 + "px", 'top': y + 20 + "px" });
}

let speedX = [];
let speedY = [];
let pos = [];
let gameover = false;
for (let i = 0; i < 7; i++) {
    speedX[i] = Math.random() * 10 - 5;
    speedY[i] = Math.random() * 10 - 5;
    pos[i] = { x: 100, y: 100 };
}


function moveCircles(index) {
    let docH = document.documentElement.clientHeight;
    let docW = document.documentElement.clientWidth;

    pos[index].x += speedX[index];
    pos[index].y += speedY[index];

    $(this).css({ 'left': pos[index].x + "px", 'top': pos[index].y + "px" });

    let r = Math.floor(Math.random() * 255);
    let g = Math.floor(Math.random() * 255);
    let b = Math.floor(Math.random() * 255);
    let col = "rgb(" + r + "," + g + "," + b + ")";

    if (pos[index].y >= docH - 100) {
        speedY[index] = Math.random() * -5;
        speedX[index] = Math.random() * 10 - 5;
        $(this).css({ 'background-color': col });
    }
    if (pos[index].y <= 0) {
        speedY[index] = Math.random() * 5;
        speedX[index] = Math.random() * 10 - 5;
        $(this).css({ 'background-color': col });
    }
    if (pos[index].x >= docW - 100) {
        speedX[index] = Math.random() * -5;
        speedY[index] = Math.random() * 10 - 5;
        $(this).css({ 'background-color': col });
    }
    if (pos[index].x <= 0) {
        speedX[index] = Math.random() * 5;
        speedY[index] = Math.random() * 10 - 5;
        $(this).css({ 'background-color': col });
    }

    //При столкновении игра заканчивается

    var ballX = pos[index].x;
    var ballY = pos[index].y;
    var ballWidth = 50;
    var ballHeight = 50;

    var heroX = x + 20;
    var heroY = y + 20;
    var heroWidth = 50;
    var heroHeight = 50;

    var rect1 = { x: ballX, y: ballY, width: ballWidth, height: ballHeight }
    var rect2 = { x: heroX, y: heroY, width: heroWidth, height: heroHeight }

    if (rect1.x < rect2.x + rect2.width &&
        rect1.x + rect1.width > rect2.x &&
        rect1.y < rect2.y + rect2.height &&
        rect1.y + rect1.height > rect2.y) {
        gameover = true;
    }
}

function move() {
    if (gameover == false)
        $(".test").each(moveCircles);
}

setInterval(move, 10);